#include "Localizer.h"

void Localizer::ReceiveTagInformation(  const tag_msgs::msg::TagPoseArray& msg,
                                        unsigned int camera_id)
{
    // la camera percoit "nb_markers" marqueurs.
    Transformation Trans;
    
    // on localise la caméra par rapport au premier marqueur fixe qui est vu.
    int first_id_seen = -1;
    for (unsigned int i=0;i<reference_markers.size();i++)
    {
        if (FoundMarker(msg,reference_markers[i].id,Trans))   if (reference_markers[i].already_seen)    // on vérifie qu'on a deja vu le marqueur
        {
            first_id_seen = i;
            // A Completer
            // calcul de la pose de la camera  dans le repere monde : cameras_poses[camera_id]
            // en fonction de la pose du marqueur de reference dans le repere monde : reference_markers[i].pose
            // et de la pose du marqueur de reference dans le repere camera : Trans

            cameras_poses[camera_id] = reference_markers[i].pose; // à  modifier
            
            break; // pour arreter la boucle for des qu'on trouve un marqueur
        }
    }    
    
    // maintenant on localise tous les autres marqueurs fixes dans le repere 1 (si ils ne sont pas connus)
    for (unsigned int i=first_id_seen+1;i<reference_markers.size();i++)
    {
        if (FoundMarker(msg,reference_markers[i].id,Trans))   if (reference_markers[i].known_reference == false)
        {
            reference_markers[i].already_seen = true;    
            // A completer 
            // calcul de la pose du marqueur de reference dans le repere monde : reference_markers[i].pose
            // en fonction de la pose de la camera  dans le repere monde : cameras_poses[camera_id]
            // et de la pose du marqueur de reference dans le repere camera : Trans
           reference_markers[i].pose = Trans;  // à  modifier
        }
    }      

    // maintenant on regarde les objets
    for (unsigned int i=0;i<objects.size();i++)
    {
        objects[i].ReInitPoseDefined();
        std::vector<unsigned int> ids = objects[i].GetIds();
        unsigned int nb = ids.size();
        for (unsigned int j=0;j<nb;j++)
        {
            // pour chaque objet on regarde si on a vu un des marqueurs
            if( FoundMarker(msg,ids[j],Trans))
            {
                Transformation local_pose = objects[i].GetLocalPose(j);
                // Calcul de la pose de l'objet dans le repere monde : object_pose
                // en fonction de la pose de la camera dans le repere monde : cameras_poses[camera_id]
                // de la pose du marqueur dans le repere de l'objet : local_pose
                // et de la pose du marqueur dans le repere camera : Trans
                Transformation object_pose = local_pose;  // à  modifier

                // on stoque la valeur
                objects[i].SetGlobalPose( object_pose);
            }
        }
    }
}


//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////Ne pas modifier sous cette ligne////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

Localizer::Localizer(rclcpp::Node* node,unsigned int nb_cam ): node_(node), nb_cameras(nb_cam)
{
    SetNbCamera(nb_cam);
    br_ = std::make_shared<tf2_ros::TransformBroadcaster>(*node);
}

Localizer::~Localizer()
{

}

void Localizer::AddObjectStaticMarkers(const YAML::Node& node)
{
    Object new_object( node["name"].as<std::string>() ) ;
    YAML::Node config = node;
    for (YAML::const_iterator it=config.begin();it!=config.end();++it)
    {
        if ( it->first.as<std::string>() == "marker" )
        {
            new_object.add_marker(ReadMarkerInfo(it->second));
        }
    }
    objects.push_back(new_object);
}

void Localizer::AddReferenceStaticMarkers(const YAML::Node& node)
{
    YAML::Node config = node;
    for (YAML::const_iterator it=config.begin();it!=config.end();++it) 
    {
        reference_markers.push_back( ReadMarkerInfo(it->second)) ;
    }
    
    // on est obligé de connaitre le premier
    reference_markers[0].already_seen = true;
}

bool Localizer::FoundMarker(    const tag_msgs::msg::TagPoseArray& msg,
                                const unsigned int id,
                                Transformation & marker)
{
    unsigned int nb_markers = msg.tags.size();
    for (unsigned int i=0;i<nb_markers;i++)
    {
        const tag_msgs::msg::TagPose& m = msg.tags[i];
        if (m.id == id)
        {
            marker = Transformation(m.pose.pose);
            return true;
        }
    }
    return false;
}

void Localizer::InitStaticMarkers(const std::string & filename )
{      
    RCLCPP_INFO(node_->get_logger(), "Filename = %s", filename.c_str());
    YAML::Node config = YAML::LoadFile(filename);          
    for (YAML::const_iterator it=config.begin();it!=config.end();++it) 
    {
        if ( it->first.as<std::string>() == "static" )
        {
            RCLCPP_INFO(node_->get_logger(), "AddReferenceStaticMarkers");
            AddReferenceStaticMarkers(it->second);
        }else if ( it->first.as<std::string>() == "object" )
        {
            RCLCPP_INFO(node_->get_logger(), "AddObjectStaticMarkers");
            AddObjectStaticMarkers(it->second);
        }
    }
}

void Localizer::PublishTF()
{
    // frame_vector_.clear();
    
    // publie reperes cameras
    for (unsigned int i=0;i<nb_cameras;i++)
    {      
        auto transform = cameras_poses[i].convertToTransformStamped( ref, "camera_"+std::to_string(i), node_->now());
        br_->sendTransform(transform);
    }
    
    // publie repere marqueur fixes
    for (unsigned int i=0;i<reference_markers.size();i++)    if (reference_markers[i].already_seen)
    {
        // frame_vector_.push_back(tf::StampedTransform(reference_markers[i].pose.convertToTF(), ros::Time::now(),ref,"marker_"+std::to_string(reference_markers[i].id)));
        auto transform = reference_markers[i].pose.convertToTransformStamped( ref, "marker_"+std::to_string(reference_markers[i].id), node_->now());
        br_->sendTransform(transform);
    }
    
    for (unsigned int i=0;i<objects.size();i++)  if( objects[i].IsDefined())
    {
        auto transform = objects[i].GetGlobalPose().convertToTransformStamped( ref, objects[i].GetName(), node_->now());
        br_->sendTransform(transform);
    }
}


marker Localizer::ReadMarkerInfo( const YAML::Node& node)
{
    marker out;
    out.id = node["id"].as<int>();
    
    double x = node["position"]["x"].as<double>();
    double y = node["position"]["y"].as<double>();
    double z = node["position"]["z"].as<double>();
    
    double roll = node["orientation"]["roll"].as<double>();
    double pitch = node["orientation"]["pitch"].as<double>();
    double yaw = node["orientation"]["yaw"].as<double>();    
    
    out.pose = Transformation(x,y,z,roll,pitch,yaw);
    
    out.known_reference = node["known_pose"].as<bool>();
    
    out.already_seen = out.known_reference;
    

    RCLCPP_INFO(node_->get_logger(), "Read marker %d ", out.id);

    return out;
}



