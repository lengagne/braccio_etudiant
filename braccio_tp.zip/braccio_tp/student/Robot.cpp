
#include "Robot.h"


Robot::Robot()
{
    // ici on peut initialiser des variables qui sont déclarées dans Robot.h
    // A MODIFIER
    
    TJoint.resize(1);   // on définit que le vecteur TJoint (vecteur de transformation) va avoir un élément (qu'on ne connait pas encore)
    TLink.resize(1);    // on définit que le vecteur TLink  (vecteur de transformation) va avoir un élément (qu'on ne connait pas encore)
    
    // on initialise des variables
    TStatic.push_back( Transformation (0,0,0,0,0,0));// on rajoute une transformation au vecteur TStatic : angle en degré
    
    // A COMPLETER 
    qmin.push_back(0);      qmax.push_back(PI);          //  on ajoute une valeur au vecteur qmin et qmax
}

// renvoi la pose de l'effecteur en fonction des variables articulaires Q.
Transformation Robot::ModGeoDirect( const VECTOR& Q)
{
    double q1 = Q.data[0];
    double q2 = Q.data[1];
    double q3 = Q.data[2];
    double q4 = Q.data[3];
    double q5 = Q.data[4];
    
    // A COMPLETER
    Transformation Teff;
    

    return Teff;
}

// Cette fonction calcule les valeurs articulaires pour que l'effecteur atteigne le point définit par le vecteur pos.
// Si le point n'est pas accessible, la fonction renvoie false
bool  Robot::ModGeoInverse( const Eigen::Matrix<double,3,1> & pos,
                            VECTOR & Q)
{    
    Q.data.resize(6);
    double q1,q2,q3,q4,q5;
    
    // A COMPLETER
    q1 = 0.0;
    q2 = 1.57;
    q3 = 0.0;
    q4 = 0.0;
    q5 = 0.0;


    // on recopie les valeurs
    
    Q.data[0] = q1;
    Q.data[1] = q2;
    Q.data[2] = q3;
    Q.data[3] = q4;
    Q.data[4] = q5;

    
    // ne pas oublier de vérifier que les valeurs sont dans les limites articulaires
    for (int i=0;i<5;i++)   // on ne vérifie pas le gripper
    {
        if (Q.data[i] < qmin[i]) Q.data[i] = qmin[i];
        if (Q.data[i] > qmax[i]) Q.data[i] = qmax[i];
    }    
    
    return true;
}

// Renvoie la jacobienne (position en 3D d'un point de l'effecteur) pour un vecteur articulaire
Eigen::Matrix<double,3,5> Robot::ComputeJacobian( const VECTOR& Q)
{
    Eigen::Matrix<double,3,5> out;
    out(0,0) = 0.0; // à implémenter
    out(0,1) = 0.0; // à implémenter
    out(0,2) = 0.0; // à implémenter
    out(0,3) = 0.0; // à implémenter
    out(0,4) = 0.0; // à implémenter
    out(1,0) = 0.0; // à implémenter
    out(1,1) = 0.0; // à implémenter
    out(1,2) = 0.0; // à implémenter
    out(1,3) = 0.0; // à implémenter
    out(1,4) = 0.0; // à implémenter
    out(2,0) = 0.0; // à implémenter
    out(2,1) = 0.0; // à implémenter
    out(2,2) = 0.0; // à implémenter
    out(2,3) = 0.0; // à implémenter
    out(2,4) = 0.0; // à implémenter

    return out;
}



// Calcule le vecteur articulaire suivant permettant de se rapprocher de la cible
// entrees
//      Qin : Vecteur articulaire initial
//      CurrentPosition : Position (vecteur 3D) actuelle de l'effecteur (par modèle ou par mesure)
//      DesiredPosition : Position (vecteur 3D) désirée de l'effecteur
// sorties
//      Qout : Vecteur articulaire permettant de se rapprocher de la cible
//      retourne la distance entre la position actuelle et désirée
double Robot::ComputeControl(   const VECTOR& Qin,
                                const Eigen::Matrix<double,3,1>& CurrentPosition,
                                const Eigen::Matrix<double,3,1>& DesiredPosition,
                                VECTOR& Qout)
{
    Qout = Qin; // à modifier

    // on vérifie les butées articulaires
    for (int i=0;i<5;i++)   // on ne vérifie pas le gripper
    {
        if (Qout.data[i] < qmin[i])
            Qout.data[i] = qmin[i];
        if (Qout.data[i] > qmax[i])
            Qout.data[i] = qmax[i];
    }

    // on renvoie la distance
    return (DesiredPosition-CurrentPosition).norm();
}
